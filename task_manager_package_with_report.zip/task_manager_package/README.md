# Simple Task Manager – Fully Functional Rails App

To run:
1. `bundle install`
2. `rails db:migrate`
3. `rails server`

RSpec: `bundle exec rspec`
Cucumber: `bundle exec cucumber`